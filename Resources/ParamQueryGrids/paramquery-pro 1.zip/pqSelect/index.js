/**
 * ParamQuery Select
 * 
 * Copyright (c) 2012-2023 Paramvir Dhindsa (http://paramquery.com)
 * Released under Evaluation license
 * http://paramquery.com/pro/license/evaluate
 * 
 */
require('jquery-ui-pack');

require("./pqselect.dev.css");

module.exports = require("./pqselect.dev.js");